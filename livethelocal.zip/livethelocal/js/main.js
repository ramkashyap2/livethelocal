(function ($) {
  "use strict";

  $(window).on("load", function () {
    $("body").addClass("loaded");
  });


  /*--
	Header Search Toggle
    -----------------------------------*/

  /* slider active */
  $(".slider-active").owlCarousel({
    loop: true,
     dots: true,
    navText: [
      '<i class="icon-arrow-left"></i>',
      '<i class="icon-arrow-right"></i>',
    ],
    nav: true,
    autoplay: true,
    autoplayTimeout: 4000,
    // animateOut: "fadeOut",
    // animateIn: "fadeIn",
    item: 1,
    responsive: {
      0: {
        items: 1,
      },
      768: {
        items: 1,
      },
      1000: {
        items: 1,
      },
    },
  });

  /* mask slider active */
  $(".slider-mask").owlCarousel({
    loop: true,
     dots: true,
    navText: [
      '<i class="icon-arrow-left"></i>',
      '<i class="icon-arrow-right"></i>',
    ],
    nav: true,
    autoplay: true,
    autoplayTimeout: 4000,
    // animateOut: "fadeOut",
    // animateIn: "fadeIn",
    item: 1,
    responsive: {
      0: {
        items: 1,
      },
      768: {
        items: 1,
      },
      1000: {
        items: 1,
      },
    },
  });


  /*--
    Menu Stick
    -----------------------------------*/
  var header = $(".transparent-bar");
  var win = $(window);

  win.on("scroll", function () {
    var scroll = win.scrollTop();
    if (scroll < 80) {
      header.removeClass("stick");
    } else {
      header.addClass("stick");
    }
  });

  // Prevent closing from click inside dropdown
$(document).on('click', '.dropdown-menu', function (e) {
  e.stopPropagation();
});

// make it as accordion for smaller screens
if ($(window).width() < 992) {
  $('.dropdown-menu a').click(function(e){
      if($(this).attr('href') == '#')
        e.preventDefault();
      if($(this).next('.submenu').length){
        $(this).next('.submenu').toggle();
      }
      $('.dropdown').on('hide.bs.dropdown', function () {
     $(this).find('.submenu').hide();
  })
  });
}

$('.plus').on('click', function() {
  if ($(this).prev().val()) {
      $(this).prev().val(+$(this).prev().val() + 1);
  }
});
$('.minus').on('click', function() {
  if ($(this).next().val() > 1) {
      if ($(this).next().val() > 1) $(this).next().val(+$(this).next().val() - 1);
  }
}); /*===================================*
24. CHECKBOX CHECK THEN ADD CLASS JS
*===================================*/
$('.create-account,.different_address').hide();
$('#createaccount:checkbox').on('change', function() {
    if ($(this).is(":checked")) {
        $('.create-account').slideDown();
    } else {
        $('.create-account').slideUp();
    }
});
$('#differentaddress:checkbox').on('change', function() {
    if ($(this).is(":checked")) {
        $('.different_address').slideDown();
    } else {
        $('.different_address').slideUp();
    }
});


})(jQuery);
